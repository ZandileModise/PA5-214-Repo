var indexSectionsWithContent =
{
  0: "cdikoprstw",
  1: "cdikoprstw",
  2: "cdioprstw",
  3: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Pages"
};

